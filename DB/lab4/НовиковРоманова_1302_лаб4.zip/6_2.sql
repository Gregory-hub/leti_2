SELECT j.member_no, a.street, a.city, a.state, a.zip, DATEADD(YY, 1, GETDATE()) as date_plus
FROM adult a
JOIN juvenile j ON j.adult_member_no = a.member_no
WHERE DATEDIFF(YY, j.birth_date, GETDATE()) > 18;