UPDATE member
SET lastname = 'Ros'
WHERE member_no = 507