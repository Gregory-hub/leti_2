SELECT *
FROM item
WHERE isbn = 10101 AND title_no = 8 AND cover = 'SOFTBACK'