--SELECT title_no
--FROM title
--WHERE title = 'The Art of Lawn Tennis'

SELECT IDENT_CURRENT('title') as title_no