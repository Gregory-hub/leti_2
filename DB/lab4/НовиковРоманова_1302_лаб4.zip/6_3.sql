INSERT INTO adult (member_no, street, city, state, zip, expr_date)
SELECT j.member_no, a.street, a.city, a.state, a.zip, DATEADD(YY, 1, GETDATE())
FROM adult a
JOIN juvenile j ON j.adult_member_no = a.member_no
WHERE DATEDIFF(YY, j.birth_date, GETDATE()) > 18;

--SELECT *
--FROM adult