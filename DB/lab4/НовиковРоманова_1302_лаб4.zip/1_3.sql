SELECT translation
FROM item
WHERE title_no = 8 AND isbn = 10001;