--INSERT INTO copy (isbn, copy_no, title_no, on_loan)
--VALUES (10001, 1, 8, 'N')

SELECT *
FROM copy
WHERE isbn = 10001 AND copy_no = 1 AND title_no = 8 AND on_loan = 'N'