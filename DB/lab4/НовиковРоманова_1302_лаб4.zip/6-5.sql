DELETE FROM juvenile
WHERE member_no IN (
  SELECT j.member_no
  FROM juvenile j
  LEFT JOIN adult a ON j.member_no = a.member_no
);
