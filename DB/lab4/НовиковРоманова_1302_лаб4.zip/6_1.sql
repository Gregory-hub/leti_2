--USE library
--BEGIN TRANSACTION
--SET IDENTITY_INSERT member ON
--INSERT member (member_no, lastname, firstname, middleinitial) 
--VALUES (16101, 'Walters', 'B.', 'L')
--SET IDENTITY_INSERT member OFF
--INSERT juvenile
--VALUES (16101, 1, DATEADD(YY, -18, DATEADD(DD, -1, GETDATE())))
--COMMIT TRANSACTION

SELECT *
FROM member m, juvenile j
WHERE m.member_no = 16101 AND j.member_no = 16101