SELECT TOP 1 * 
FROM title 
ORDER BY title_no DESC;
