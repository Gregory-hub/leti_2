--INSERT INTO title (title, author)
--VALUES ('Riders of the Purple Sage', 'Zane Grey')

SELECT *
FROM title
WHERE title = 'Riders of the Purple Sage'