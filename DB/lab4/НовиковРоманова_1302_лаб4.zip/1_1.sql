INSERT INTO item (isbn, title_no, cover, loanable, translation)
VALUES (10001, 8, 'HARDBACK', 'Y', 'ENGLISH'),
	  (10101, 8, 'SOFTBACK', 'Y', 'ENGLISH');
