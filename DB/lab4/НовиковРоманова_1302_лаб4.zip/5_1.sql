SELECT*
FROM member
WHERE member_no = 507