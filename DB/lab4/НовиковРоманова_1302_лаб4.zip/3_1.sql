USE library
CREATE TABLE sample1 (
	Cust_id int NOT NULL IDENTITY(100,5),
	Name char(10) NULL)

--DROP TABLE sample1