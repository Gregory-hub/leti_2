--INSERT INTO title (title, author, synopsis)
--VALUES ('The Art of Lawn Tennis', 'Williams T.Tilden', DEFAULT)

SELECT *
FROM title
WHERE title = 'The Art of Lawn Tennis'