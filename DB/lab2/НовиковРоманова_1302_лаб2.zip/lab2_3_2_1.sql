SELECT ProductID, SUM(LineTotal) AS TOTAL
FROM Sales.SalesOrderDetail
WHERE UnitPrice < 5
GROUP BY ProductID
ORDER BY ProductID;
