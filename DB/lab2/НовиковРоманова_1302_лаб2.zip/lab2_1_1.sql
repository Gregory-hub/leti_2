SELECT SalesPersonID, Bonus 
FROM Sales.SalesPerson 
ORDER BY Bonus DESC;
