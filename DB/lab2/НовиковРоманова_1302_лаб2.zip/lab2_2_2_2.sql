SELECT ProductID, SUM(OrderQty)
AS SUM FROM Sales.SalesOrderDetail
GROUP BY ProductID
ORDER BY SUM DESC;
