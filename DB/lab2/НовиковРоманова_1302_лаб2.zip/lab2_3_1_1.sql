SELECT SalesQuota, SUM(SalesYTD) AS TotalSalesYTD
FROM Sales.SalesPerson
GROUP BY SalesQuota;