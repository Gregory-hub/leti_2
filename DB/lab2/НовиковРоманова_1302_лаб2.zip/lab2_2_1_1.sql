SELECT COUNT(*)
FROM HumanResources.Employee;
