SELECT ProductID, SpecialOfferID, AVG(UnitPrice) AS Price, SUM(LineTotal) AS Total
FROM Sales.SalesOrderDetail
GROUP BY ProductID, SpecialOfferID;