SELECT ProductID, SUM(LineTotal) AS TOTAL
FROM Sales.SalesOrderDetail
WHERE UnitPrice < 5
GROUP BY CUBE(ProductID, OrderQty)
ORDER BY ProductID;
