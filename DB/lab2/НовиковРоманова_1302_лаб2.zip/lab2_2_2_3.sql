SELECT ProductID, SUM(OrderQty)
AS SUM FROM Sales.SalesOrderDetail
GROUP BY ProductID
HAVING SUM(OrderQty) >= 2000
ORDER BY SUM DESC;
