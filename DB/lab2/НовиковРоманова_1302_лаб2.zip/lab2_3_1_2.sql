SELECT SalesQuota, SUM(SalesYTD) AS TotalSalesYTD, GROUPING(SalesQuota) AS GROUPING
FROM Sales.SalesPerson
GROUP BY ROLLUP(SalesQuota);