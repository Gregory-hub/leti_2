SELECT COUNT(ManagerID)
FROM HumanResources.Employee;
