SELECT TOP(4) SalesPersonID, Bonus 
FROM Sales.SalesPerson 
ORDER BY Bonus DESC;
