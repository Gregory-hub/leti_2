Use Master

-- Setup user for execution context
IF NOT EXISTS (SELECT * FROM sys.syslogins WHERE name = 'TULENCHI\olya-')
	CREATE LOGIN [TULENCHI\olya-]
	FROM WINDOWS
	WITH DEFAULT_DATABASE = adventure
GO

Use adventure

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'olya-' AND type = 'U')
	CREATE USER Adam FOR LOGIN [TULENCHI\olya-]
GO

-- Setup data
UPDATE	Sales.SpecialOffer 
SET		StartDate = DateAdd(day, -1, GetDate()), 
		EndDate = DateAdd(day, 27, GetDate())
WHERE	SpecialOfferId IN (1,3,5,7,9,11,13,15)

UPDATE	Sales.SpecialOffer 
SET		StartDate = DateAdd(day, 28, GetDate()), 
		EndDate = DateAdd(month, 2, GetDate())
WHERE	SpecialOfferId IN (2,4,6,8,10,12,14,16)
GO
