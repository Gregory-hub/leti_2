SELECT * FROM Sales.GetDiscountedProducts(0)
SELECT * FROM Sales.GetDiscountedProducts(1)