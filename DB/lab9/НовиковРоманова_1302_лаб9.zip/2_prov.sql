SELECT * 
FROM Sales.GetDiscountForDate(GetDate())
ORDER BY DiscountPct DESC