IF OBJECT_ID ('Sales.GetDiscountForDate', 'FN') IS NOT NULL
DROP FUNCTION Sales.GetDiscountForDate
GO

CREATE FUNCTION Sales.GetDiscountForDate (@DateToCheck datetime)
RETURNS TABLE
RETURN (
	SELECT 
	Description, 
	DiscountPct,
	Type,
	Category, 
	StartDate, 
	EndDate, 
	MinQty, 
	MaxQty
	FROM Sales.SpecialOffer
	WHERE StartDate <= @DateToCheck AND EndDate >= @DateToCheck
	ORDER BY StartDate, EndDate OFFSET 0 ROW
	)
	 
