IF OBJECT_ID ('Sales.GetMaximumDiscountForCategory', 'FN') IS NOT NULL
DROP FUNCTION Sales.GetMaximumDiscountForCategory
GO

CREATE FUNCTION Sales.GetMaximumDiscountForCategory (@Category nvarchar(50))
RETURNS smallmoney

BEGIN
	DECLARE @Max smallmoney
	SELECT @Max = MAX(DiscountPct)
	FROM Sales.SpecialOffer
	WHERE Category = @Category AND GETDATE() >= StartDate AND GETDATE() <= EndDate
	RETURN @Max
END
