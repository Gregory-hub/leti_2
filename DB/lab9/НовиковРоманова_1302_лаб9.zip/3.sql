IF OBJECT_ID ('Sales.GetDiscountedProducts', 'FN') IS NOT NULL
DROP FUNCTION Sales.GetDiscountedProducts
GO

CREATE FUNCTION Sales.GetDiscountedProducts (@IncludeHistory bit)
RETURNS TABLE
AS
RETURN
	SELECT 
	p.ProductID,
	p.Name,
	p.ListPrice,
	so.Description AS DiscountDescription,
	so.DiscountPct AS DiscountPercentage,
	p.ListPrice * so.DiscountPct AS DiscountAmount,
	p.ListPrice - p.ListPrice * so.DiscountPct AS DiscountedPrice
	FROM Sales.SpecialOffer so, Production.Product p
	WHERE 
	(@IncludeHistory = 1)
	OR
	(GETDATE() BETWEEN so.StartDate AND so.EndDate);
