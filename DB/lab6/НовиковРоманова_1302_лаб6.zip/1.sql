CREATE TABLE HumanResources.JobCandidateHistory
(
	JobCandidateID int NOT NULL PRIMARY KEY,
	Resume xml,
	Rating int NOT NULL CHECK (Rating > 0 and Rating < 11) default 5,
	RejectedDate datetime NOT NULL,
	ContactID int references Person.Contact(ContactID)
);