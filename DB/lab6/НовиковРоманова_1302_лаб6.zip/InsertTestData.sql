USE [adventure]

-- Insert the test data
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(1,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(2,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(3,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(4,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(5,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(6,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(7,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(8,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(9,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(10,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(11,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(12,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(13,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(14,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(15,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(16,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(17,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(18,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(19,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(20,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(21,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(22,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(23,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(24,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(25,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(26,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(27,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(28,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(29,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(30,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(31,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(32,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(33,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(34,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(35,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(36,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(37,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(38,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(39,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
INSERT INTO [HumanResources].[JobCandidateHistory]
VALUES
(40,
'<ns:Resume xmlns:ns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume">
  <ns:ResumeData></ns:ResumeData>
</ns:Resume>'
,6
,GETDATE()
,1)
GO
TRUNCATE TABLE HumanResources.JobCandidateHistory
