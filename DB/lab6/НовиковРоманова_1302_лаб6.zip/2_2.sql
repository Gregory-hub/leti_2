ALTER TABLE HumanResources.JobCandidateHistory 
CHECK CONSTRAINT [CK__JobCandid__Ratin__6B44E613]