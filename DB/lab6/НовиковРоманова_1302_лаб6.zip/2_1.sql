USE [adventure]
GO
ALTER TABLE HumanResources.JobCandidateHistory 
NOCHECK CONSTRAINT [CK__JobCandid__Ratin__6B44E613] 
GO