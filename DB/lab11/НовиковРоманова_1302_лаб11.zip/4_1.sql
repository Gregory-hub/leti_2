USE AdventureWorks
GO
IF OBJECT_ID ('Sales.OrderDetailNotDiscounted','TR') IS NOT NULL
   DROP TRIGGER Sales.OrderDetailNotDiscounted;
GO
CREATE TRIGGER OrderDetailNotDiscounted
ON Sales.SalesOrderDetail
FOR INSERT
AS 
BEGIN
    IF EXISTS (
        SELECT 1
        FROM inserted i
        INNER JOIN Production.Product p ON i.ProductID = p.ProductID
        WHERE p.DiscontinuedDate IS NOT NULL
    )
    BEGIN
        RAISERROR ('Deliveries of thos product have been discounted.', 16, 1)
        ROLLBACK TRANSACTION
    END
END
