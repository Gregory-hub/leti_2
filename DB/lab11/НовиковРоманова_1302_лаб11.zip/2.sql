USE AdventureWorks
GO
IF OBJECT_ID ('dJobCandidate','TR') IS NOT NULL
   DROP TRIGGER dJobCandidate;
GO
CREATE TRIGGER dJobCandidate
ON HumanResources.JobCandidate
AFTER DELETE
AS 
IF EXISTS (SELECT JobCandidateID FROM deleted)
BEGIN
INSERT HumanResources.JobCandidateHistory (JobCandidateID, Resume, RejectedDate, Rating, ContactID)
VALUES ((SELECT JobCandidateID FROM deleted),(SELECT Resume FROM deleted), GETDATE(), DEFAULT, NULL)
END
